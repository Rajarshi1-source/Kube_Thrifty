#!/usr/bin/env python3
"""
detective/engine.py -- a runnable slice of ThriftDetective.

CONTRACT: investigate(bundle) is a PURE function. Same bundle in, byte-identical verdicts out, forever.
No network, no clock, no randomness, no LLM in the decision path. That property is what makes verdicts
replayable offline, unit-testable, and hash-assertable in CI (see ../detective_eval.py).

Scope discipline: five resource-shaped failure modes. Anything else returns NO VERDICT with an explicit
scope statement rather than a low-confidence guess -- a tool that never says "I don't know" cannot be
trusted when it does say something.

The differentiator is `_attribute`: every verdict tries to name the KubeThrifty change that caused the
incident (merged PR, recommendation id, resize event) inside a time window on the same container. No
external investigator can do that, because none of them owns the change log.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, asdict
from typing import Callable, Optional

RULESET_VERSION = "1.0.0"
ATTRIBUTION_WINDOW_HOURS = 48


@dataclass(frozen=True)
class Verdict:
    rule_id: str
    confidence: float                     # calibrated; scored by detective_eval.py
    summary: str
    evidence: dict
    attributed_change: Optional[dict] = None
    remediation: str = ""


Rule = Callable[[dict], Optional[Verdict]]
RULES: list[Rule] = []


def rule(fn: Rule) -> Rule:
    RULES.append(fn)
    return fn


def _attribute(b: dict) -> Optional[dict]:
    """Did WE cause this? Correlate with KubeThrifty's own change log."""
    changes = sorted(b.get("kubethrifty_changes", []),
                     key=lambda c: c["hours_before_incident"])
    for ch in changes:
        if (ch["hours_before_incident"] <= ATTRIBUTION_WINDOW_HOURS
                and ch.get("container") == b.get("container")):
            return {
                "recommendation_id": ch.get("recommendation_id"),
                "pr": ch.get("pr_url"),
                "kind": ch.get("kind"),
                "hours_before": ch["hours_before_incident"],
                "delta": ch.get("delta"),
            }
    return None


# ---------------------------------------------------------------------------- rules
@rule
def mem_limit_too_low(b: dict) -> Optional[Verdict]:
    if b["signals"].get("oom_kills", 0) <= 0:
        return None
    peak = b["cgroup"].get("memory_peak", 0)
    limit = b["cgroup"].get("memory_max") or 0          # None/0 == unlimited -> no ratio
    ratio = (peak / limit) if limit else 0.0
    conf = 0.97 if ratio > 0.95 else 0.85 if b.get("exit_code") == 137 else 0.70
    change = _attribute(b)
    if change and "memory" in (change.get("delta") or {}):
        conf = min(0.99, conf + 0.02)
    return Verdict(
        "MEM_LIMIT_TOO_LOW", round(conf, 3),
        "Container was OOMKilled; the memory limit is below real demand.",
        {"oom_kills": b["signals"]["oom_kills"], "memory_peak": peak, "memory_max": limit,
         "peak_over_limit": round(ratio, 3), "exit_code": b.get("exit_code")},
        change,
        "Raise memory request/limit to peak x 1.25 and mark the workload reduction-blocked for 14 days.",
    )


@rule
def mem_pressure_no_kill(b: dict) -> Optional[Verdict]:
    """Reclaim thrash: slow, not dead. Invisible to every percentile-only tool."""
    psi = b["signals"].get("psi_mem_full")
    if psi is None or psi < 0.05 or b["signals"].get("oom_kills", 0) > 0:
        return None
    cur = b["cgroup"].get("memory_current", 0)
    limit = b["cgroup"].get("memory_max") or 0
    near_limit = bool(limit) and cur / limit > 0.90
    return Verdict(
        "MEM_PRESSURE_NO_KILL", 0.88 if near_limit else 0.62,
        "Sustained memory stall without an OOM kill -- the workload is thrashing reclaim, so average "
        "usage understates real demand.",
        {"psi_mem_full": psi, "memory_current": cur, "memory_max": limit,
         "current_over_limit": round(cur / limit, 3) if limit else None},
        _attribute(b),
        "Increase memory; do NOT size this workload from percentile usage.",
    )


@rule
def cpu_limit_too_low(b: dict) -> Optional[Verdict]:
    tr = b["signals"].get("throttle_ratio")
    if tr is None or tr < 0.05:
        return None
    psi = b["signals"].get("psi_cpu_full") or 0.0
    return Verdict(
        "CPU_LIMIT_TOO_LOW", 0.90 if psi > 0.02 else 0.72,
        "The CPU limit is throttling the workload.",
        {"throttle_ratio": tr, "psi_cpu_full": psi},
        _attribute(b),
        "Raise the CPU limit (or drop it and let requests schedule); keep the request as sized.",
    )


@rule
def hpa_coupling_storm(b: dict) -> Optional[Verdict]:
    hpa, change = b.get("hpa"), _attribute(b)
    if not hpa or not change:
        return None
    before, after = hpa.get("replicas_before"), hpa.get("replicas_after")
    if not (before and after and after > before * 1.5):
        return None
    return Verdict(
        "HPA_COUPLING_STORM", 0.93,
        "Replica count grew sharply after a request reduction -- the HPA is reacting to higher "
        "utilisation-of-request, not to more traffic.",
        {"replicas_before": before, "replicas_after": after,
         "hpa_target": hpa.get("target_utilization"),
         "traffic_delta_pct": hpa.get("traffic_delta_pct")},
        change,
        "Re-derive the HPA target for the new request, or revert the request.",
    )


@rule
def resize_infeasible_stuck(b: dict) -> Optional[Verdict]:
    cond = (b.get("conditions") or {}).get("PodResizePending") or {}
    if cond.get("reason") != "Infeasible":
        return None
    return Verdict(
        "RESIZE_INFEASIBLE_STUCK", 0.99,
        "An in-place resize cannot be satisfied on this node.",
        {"condition": cond, "node_allocatable": b.get("node_allocatable")},
        _attribute(b),
        "Abandon the rehearsal (never wait indefinitely); recommend via PR only.",
    )


# ---------------------------------------------------------------------- entrypoints
def investigate(bundle: dict) -> list[Verdict]:
    verdicts = [v for v in (r(bundle) for r in RULES) if v]
    verdicts.sort(key=lambda v: (-v.confidence, v.rule_id))    # stable, deterministic order
    return verdicts


def canonical(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


def bundle_sha256(bundle: dict) -> str:
    """The incident's identity. Canonical JSON, or the same bundle hashes differently per machine."""
    return hashlib.sha256(canonical(bundle).encode()).hexdigest()


def verdicts_digest(verdicts: list[Verdict]) -> str:
    """Determinism anchor asserted in CI."""
    return hashlib.sha256(canonical([asdict(v) for v in verdicts]).encode()).hexdigest()


def explain(bundle: dict) -> str:
    """Deterministic narration. The optional LLM narrator in the real project phrases this, never
    decides it -- the verdict is computed first and the narration is validated against it."""
    vs = investigate(bundle)
    if not vs:
        return ("NO_VERDICT: outside ThriftDetective's scope -- this is not a resource-shaped incident. "
                "Resource signals look healthy; look at image pull, DNS, RBAC, storage or the app itself.")
    lines = []
    for v in vs:
        attrib = ""
        if v.attributed_change:
            a = v.attributed_change
            attrib = (f" ATTRIBUTED to {a.get('kind')} {a.get('pr') or a.get('recommendation_id')} "
                      f"{a.get('hours_before')}h before ({a.get('delta')}).")
        lines.append(f"{v.rule_id} ({v.confidence:.0%}): {v.summary}{attrib} -> {v.remediation}")
    return "\n".join(lines)
