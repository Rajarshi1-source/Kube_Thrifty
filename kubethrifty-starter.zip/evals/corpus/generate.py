#!/usr/bin/env python3
"""
corpus/generate.py -- manufactures the labeled incident corpus.

In the real project this drives a kind cluster and induces each failure mode deliberately (chaos
harness), then serialises the collected evidence. Here it emits the same bundle SHAPE deterministically
so the eval gate runs hermetically in CI with no cluster and no network -- which is the point: the
corpus is a factory, not a hand-collected ceiling. Add a generator, get labeled cases the same
afternoon.

Three of the cases are RED HERRINGS whose ground truth is NO_VERDICT (image pull, DNS, healthy pod).
A tool that never says "I don't know" cannot be trusted when it does say something, so refusing these
is a graded requirement, not a nicety.

Usage:
    python generate.py            # writes incidents.json
    python generate.py --freeze   # writes incidents.json AND digests.json (the determinism anchor)
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent))            # for `detective` package
sys.path.insert(0, str(HERE.parent / "detective"))

MIB = 1024 * 1024


def bundle(*, name, container="app", exit_code=0, oom=0, throttle=None, psi_mem=None, psi_cpu=None,
           mem_current=0, mem_peak=0, mem_max=0, conditions=None, hpa=None, changes=(),
           node_allocatable=None, note="") -> dict:
    return {
        "schema": "kubethrifty.detective/v1",
        "case": name,
        "cluster": "demo", "namespace": "shop", "workload": name.split("__")[0],
        "pod": f"{name.split('__')[0]}-7d9f", "container": container,
        "exit_code": exit_code,
        "conditions": conditions or {},
        "signals": {"oom_kills": oom, "throttle_ratio": throttle,
                    "psi_mem_full": psi_mem, "psi_cpu_full": psi_cpu},
        "cgroup": {"memory_current": mem_current, "memory_peak": mem_peak, "memory_max": mem_max,
                   "oom_kill_total": oom},
        "hpa": hpa,
        "node_allocatable": node_allocatable,
        "kubethrifty_changes": list(changes),
        "collector_versions": {"cgroup_truth": "1.0.0", "engine": "1.0.0"},
        "_note": note,
    }


def merged_pr(pr: int, rec: int, hours: float, delta: dict, container="app") -> dict:
    return {"kind": "merged_pr", "pr_url": f"https://github.com/OWNER/REPO/pull/{pr}",
            "recommendation_id": rec, "commit": f"sha{pr}", "hours_before_incident": hours,
            "container": container, "delta": delta}


CASES = [
    # ============================================================================================
    # The corpus is deliberately NOT all-textbook. A corpus where every case is obvious drives
    # accuracy to 1.0 while mean confidence sits near 0.9 -- which the calibration gate correctly
    # reports as MISCALIBRATION (underconfidence). Real incidents include ambiguous ones the engine
    # gets wrong, so two cases below are genuine misfires with ground truth NO_VERDICT. They are the
    # reason the confidence numbers mean something.
    # ============================================================================================

    # ---- MEM_LIMIT_TOO_LOW, high confidence: OOM + peak pinned at the limit + our own change -----
    dict(ground_truth="MEM_LIMIT_TOO_LOW", b=bundle(
        name="payment-processor__oom_squeeze", exit_code=137, oom=1,
        throttle=0.004, psi_mem=0.11, psi_cpu=0.002,
        mem_current=318 * MIB, mem_peak=318 * MIB, mem_max=320 * MIB,
        changes=[merged_pr(212, 1188, 14.5, {"memory": "1Gi -> 320Mi"})],
        note="the flagship case: our own cut caused it, and the verdict names the PR")),
    dict(ground_truth="MEM_LIMIT_TOO_LOW", b=bundle(
        name="session-store__oom_squeeze", exit_code=137, oom=2,
        throttle=0.0, psi_mem=0.19, psi_cpu=0.0,
        mem_current=253 * MIB, mem_peak=255 * MIB, mem_max=256 * MIB,
        changes=[merged_pr(224, 1250, 30.0, {"memory": "768Mi -> 256Mi"})],
        note="same shape, different workload -- attribution window is 48h and this is 30h")),
    dict(ground_truth="MEM_LIMIT_TOO_LOW", b=bundle(
        name="report-builder__oom_no_attrib", exit_code=137, oom=3,
        throttle=0.0, psi_mem=0.22, psi_cpu=0.0,
        mem_current=505 * MIB, mem_peak=511 * MIB, mem_max=512 * MIB,
        note="OOM with no KubeThrifty change nearby -- the verdict must NOT invent attribution")),

    # ---- MEM_LIMIT_TOO_LOW, mid confidence: one huge allocation, peak well under the limit --------
    dict(ground_truth="MEM_LIMIT_TOO_LOW", b=bundle(
        name="pdf-exporter__oom_spike_attrib", exit_code=137, oom=1,
        throttle=0.0, psi_mem=0.04, psi_cpu=0.0,
        mem_current=300 * MIB, mem_peak=700 * MIB, mem_max=1024 * MIB,
        changes=[merged_pr(233, 1290, 20.0, {"memory": "2Gi -> 1Gi"})],
        note="a single large allocation: peak far below the limit, so confidence is lower even though "
             "the kill is real and attributable")),
    dict(ground_truth="MEM_LIMIT_TOO_LOW", b=bundle(
        name="image-resizer__oom_spike", exit_code=137, oom=1,
        throttle=0.0, psi_mem=0.03, psi_cpu=0.0,
        mem_current=280 * MIB, mem_peak=640 * MIB, mem_max=1024 * MIB,
        note="same shape without attribution")),

    # ---- MEM_LIMIT_TOO_LOW, low confidence: OOM counter moved but no 137 and no attribution -------
    dict(ground_truth="MEM_LIMIT_TOO_LOW", b=bundle(
        name="log-shipper__oom_counter_only", exit_code=0, oom=1,
        throttle=0.0, psi_mem=0.02, psi_cpu=0.0,
        mem_current=180 * MIB, mem_peak=420 * MIB, mem_max=512 * MIB,
        note="the cgroup oom_kill counter moved but the pod's exit code says otherwise -- a sidecar "
             "was killed, not the main container. Deliberately low confidence")),

    # ---- MEM_PRESSURE_NO_KILL, high confidence: thrashing against its OWN limit -------------------
    dict(ground_truth="MEM_PRESSURE_NO_KILL", b=bundle(
        name="inventory-cache__reclaim_thrash", oom=0,
        throttle=0.002, psi_mem=0.14, psi_cpu=0.001,
        mem_current=490 * MIB, mem_peak=498 * MIB, mem_max=512 * MIB,
        note="low average usage, high PSI: needs MORE memory. No tool without PSI can see this")),
    dict(ground_truth="MEM_PRESSURE_NO_KILL", b=bundle(
        name="search-indexer__thrash_after_cut", oom=0,
        throttle=0.01, psi_mem=0.09, psi_cpu=0.004,
        mem_current=760 * MIB, mem_peak=780 * MIB, mem_max=800 * MIB,
        changes=[merged_pr(230, 1301, 6.0, {"memory": "2Gi -> 800Mi"})],
        note="attributable thrash: our cut made it stall without killing it")),

    # ---- MEM_PRESSURE_NO_KILL, low confidence: stalling but NOT near its own limit ----------------
    dict(ground_truth="MEM_PRESSURE_NO_KILL", b=bundle(
        name="feed-worker__thrash_below_limit", oom=0,
        throttle=0.0, psi_mem=0.08, psi_cpu=0.0,
        mem_current=600 * MIB, mem_peak=620 * MIB, mem_max=1024 * MIB,
        note="genuinely under-sized despite headroom in the limit: the working set churns")),
    dict(ground_truth="NO_VERDICT", b=bundle(
        name="thumbnailer__noisy_neighbour", oom=0,
        throttle=0.0, psi_mem=0.07, psi_cpu=0.0,
        mem_current=300 * MIB, mem_peak=320 * MIB, mem_max=2048 * MIB,
        note="KNOWN MISFIRE (scored as wrong, on purpose): the stall came from another pod exhausting "
             "the node, not from this container's limit. The starter slice has no NODE_PRESSURE rule, "
             "so it answers MEM_PRESSURE_NO_KILL at 0.62 and is penalised. This is exactly how the "
             "corpus tells you which rule to write next")),

    # ---- CPU_LIMIT_TOO_LOW, high confidence: throttling AND cpu stall ----------------------------
    dict(ground_truth="CPU_LIMIT_TOO_LOW", b=bundle(
        name="checkout-api__throttle_squeeze", oom=0,
        throttle=0.31, psi_mem=0.0, psi_cpu=0.12,
        mem_current=200 * MIB, mem_peak=210 * MIB, mem_max=512 * MIB,
        changes=[merged_pr(241, 1360, 3.0, {"cpu": "1000m -> 250m"})],
        note="throttling AND stalling = real harm, and it is ours")),
    dict(ground_truth="CPU_LIMIT_TOO_LOW", b=bundle(
        name="graphql-gateway__throttle_stall", oom=0,
        throttle=0.22, psi_mem=0.0, psi_cpu=0.07,
        mem_current=350 * MIB, mem_peak=360 * MIB, mem_max=1024 * MIB,
        note="latency-sensitive service, clear stall")),

    # ---- CPU_LIMIT_TOO_LOW, low confidence: throttled but barely stalling ------------------------
    dict(ground_truth="CPU_LIMIT_TOO_LOW", b=bundle(
        name="csv-importer__throttle_light_stall", oom=0,
        throttle=0.11, psi_mem=0.0, psi_cpu=0.008,
        mem_current=160 * MIB, mem_peak=170 * MIB, mem_max=512 * MIB,
        note="user-facing import job: throttling does hurt here, but the evidence is weaker")),
    dict(ground_truth="CPU_LIMIT_TOO_LOW", b=bundle(
        name="webhook-fanout__throttle_light_stall", oom=0,
        throttle=0.08, psi_mem=0.0, psi_cpu=0.011,
        mem_current=120 * MIB, mem_peak=130 * MIB, mem_max=256 * MIB,
        note="same shape, lower throttle ratio")),
    dict(ground_truth="NO_VERDICT", b=bundle(
        name="video-encoder__harmless_throttle", oom=0,
        throttle=0.09, psi_mem=0.0, psi_cpu=0.001,
        mem_current=900 * MIB, mem_peak=950 * MIB, mem_max=2048 * MIB,
        note="KNOWN MISFIRE (scored as wrong, on purpose): a batch encoder with no latency SLO. It is "
             "throttled and it does not care -- the job finishes on time. The engine answers "
             "CPU_LIMIT_TOO_LOW at 0.72 and is penalised, which is the honest cost of not knowing "
             "whether a workload has an SLO")),

    # ---- HPA_COUPLING_STORM: the right-sizing cost paradox ---------------------------------------
    dict(ground_truth="HPA_COUPLING_STORM", b=bundle(
        name="web-frontend__hpa_paradox", oom=0,
        throttle=0.01, psi_mem=0.0, psi_cpu=0.004,
        mem_current=300 * MIB, mem_peak=310 * MIB, mem_max=1024 * MIB,
        hpa={"replicas_before": 3, "replicas_after": 8, "target_utilization": 70,
             "traffic_delta_pct": 1.0},
        changes=[merged_pr(255, 1402, 2.0, {"cpu": "1000m -> 250m"})],
        note="flat traffic, 3 -> 8 replicas: the cut raised utilisation-of-request, not load")),
    dict(ground_truth="HPA_COUPLING_STORM", b=bundle(
        name="api-gateway__hpa_paradox_falling_traffic", oom=0,
        throttle=0.0, psi_mem=0.01, psi_cpu=0.0,
        mem_current=250 * MIB, mem_peak=260 * MIB, mem_max=512 * MIB,
        hpa={"replicas_before": 4, "replicas_after": 9, "target_utilization": 60,
             "traffic_delta_pct": -2.0},
        changes=[merged_pr(261, 1440, 5.5, {"cpu": "800m -> 200m"})],
        note="traffic fell while replicas grew -- unambiguous coupling")),
    dict(ground_truth="HPA_COUPLING_STORM", b=bundle(
        name="notification-api__hpa_paradox_keda", oom=0,
        throttle=0.02, psi_mem=0.0, psi_cpu=0.006,
        mem_current=180 * MIB, mem_peak=190 * MIB, mem_max=512 * MIB,
        hpa={"replicas_before": 2, "replicas_after": 6, "target_utilization": 75,
             "traffic_delta_pct": 3.0},
        changes=[merged_pr(268, 1471, 1.5, {"cpu": "600m -> 150m"})],
        note="a KEDA-owned HPA on CPU is subject to exactly the same paradox")),

    # ---- RESIZE_INFEASIBLE_STUCK ----------------------------------------------------------------
    dict(ground_truth="RESIZE_INFEASIBLE_STUCK", b=bundle(
        name="ml-scorer__infeasible_resize", oom=0,
        throttle=0.0, psi_mem=0.0, psi_cpu=0.0,
        mem_current=1000 * MIB, mem_peak=1010 * MIB, mem_max=2048 * MIB,
        conditions={"PodResizePending": {"status": "True", "reason": "Infeasible",
                                         "message": "node has insufficient cpu"}},
        node_allocatable={"cpu_millicores": 3760, "memory_mib": 14580},
        changes=[{"kind": "rehearsal", "recommendation_id": 1500, "hours_before_incident": 0.1,
                  "container": "app", "delta": {"cpu": "500m -> 3000m"}}],
        note="a rehearsal asked for more than the node had: self-inflicted, and it must never hang")),
    dict(ground_truth="RESIZE_INFEASIBLE_STUCK", b=bundle(
        name="video-transcoder__infeasible_mem", oom=0,
        throttle=0.0, psi_mem=0.0, psi_cpu=0.0,
        mem_current=2000 * MIB, mem_peak=2010 * MIB, mem_max=4096 * MIB,
        conditions={"PodResizePending": {"status": "True", "reason": "Infeasible",
                                         "message": "node has insufficient memory"}},
        node_allocatable={"cpu_millicores": 7600, "memory_mib": 29000},
        note="no attribution available: the resize was requested by hand")),

    # ---- RED HERRINGS: the engine is REQUIRED to refuse these ------------------------------------
    dict(ground_truth="NO_VERDICT", b=bundle(
        name="notify-svc__imagepull", exit_code=0, oom=0,
        throttle=0.0, psi_mem=0.0, psi_cpu=0.0,
        mem_current=50 * MIB, mem_peak=60 * MIB, mem_max=256 * MIB,
        conditions={"ContainersReady": {"status": "False", "reason": "ImagePullBackOff",
                                        "message": "manifest unknown"}},
        note="RED HERRING: broken image tag, healthy resources")),
    dict(ground_truth="NO_VERDICT", b=bundle(
        name="auth-svc__dns_failure", exit_code=1, oom=0,
        throttle=0.001, psi_mem=0.0, psi_cpu=0.0,
        mem_current=120 * MIB, mem_peak=130 * MIB, mem_max=512 * MIB,
        changes=[merged_pr(270, 1490, 10.0, {"cpu": "500m -> 300m"})],
        note="RED HERRING and the hardest one: a DNS failure shortly after one of OUR changes. "
             "Correlation is not causation and the engine must not claim it")),
    dict(ground_truth="NO_VERDICT", b=bundle(
        name="cron-cleanup__crashloop_bad_config", exit_code=2, oom=0,
        throttle=0.0, psi_mem=0.0, psi_cpu=0.0,
        mem_current=30 * MIB, mem_peak=35 * MIB, mem_max=256 * MIB,
        note="RED HERRING: the app exits 2 on a bad config file. Resources are irrelevant")),
    dict(ground_truth="NO_VERDICT", b=bundle(
        name="static-site__healthy", oom=0,
        throttle=0.0, psi_mem=0.0, psi_cpu=0.0,
        mem_current=40 * MIB, mem_peak=45 * MIB, mem_max=256 * MIB,
        note="RED HERRING: nothing is wrong at all")),
]


def main() -> int:
    from engine import investigate, verdicts_digest, RULESET_VERSION   # noqa: E402

    corpus = [{"name": c["b"]["case"], "ground_truth": c["ground_truth"], "bundle": c["b"]}
              for c in CASES]
    (HERE / "incidents.json").write_text(json.dumps(corpus, indent=2, sort_keys=True) + "\n")
    print(f"wrote incidents.json: {len(corpus)} cases "
          f"({sum(1 for c in corpus if c['ground_truth'] == 'NO_VERDICT')} red herrings)")

    if "--freeze" in sys.argv:
        digests = {RULESET_VERSION: [verdicts_digest(investigate(c["bundle"])) for c in corpus]}
        (HERE / "digests.json").write_text(json.dumps(digests, indent=2) + "\n")
        print(f"wrote digests.json for ruleset {RULESET_VERSION} (determinism anchor)")
        print("NOTE: only re-freeze after checking Brier/ECE -- re-freezing blindly defeats the gate.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
