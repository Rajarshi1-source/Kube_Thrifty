#!/usr/bin/env python3
"""
forecaster.py — the provider-agnostic Forecaster used by the eval harness and (in the real
project) by the analyser. Mirrors analyser/src/forecasting/ but is self-contained here so the
starter's eval gate runs with zero heavy dependencies.

Two implementations:
  - StatsForecaster:        wraps statsforecast AutoETS (the production default). Used if installed.
  - SeasonalNaiveForecaster: dependency-free (numpy only). Linear trend + hour-of-week seasonal
                             profile + empirical residual interval. This is BOTH the deterministic
                             fallback the project relies on AND what lets CI score the harness fast
                             without native ML deps.

`confident=False` is the contract that tells the caller to fall back to trailing P95.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol
import numpy as np
import pandas as pd

MIN_POINTS = 24 * 14          # need ~2 weeks of hourly data to trust a forecast
WEEK = 24 * 7
Z90 = 1.645                   # one-sided 95th / two-sided 90% normal quantile


@dataclass
class Forecast:
    horizon_hours: int
    point: pd.Series          # predicted mean per future hour
    lower: pd.Series          # lower bound of the (~90%) interval
    upper: pd.Series          # upper bound — used as the predictive FLOOR by the engine
    model_id: str             # provenance, recorded on every recommendation
    confident: bool           # False -> caller falls back to trailing P95


class Forecaster(Protocol):
    def forecast(self, history: pd.Series, horizon_hours: int) -> Forecast: ...


class SeasonalNaiveForecaster:
    """numpy-only. Captures linear trend + weekly (hour-of-week) seasonality."""
    MODEL_ID = "seasonal-naive:hour-of-week+trend"

    def forecast(self, history: pd.Series, horizon_hours: int) -> Forecast:
        y = history.dropna().to_numpy(dtype=float)
        n = len(y)
        future_index = pd.RangeIndex(n, n + horizon_hours)
        if n < MIN_POINTS:
            flat = pd.Series(np.repeat(y[-1] if n else 0.0, horizon_hours), index=future_index)
            return Forecast(horizon_hours, flat, flat, flat, self.MODEL_ID, confident=False)

        t = np.arange(n)
        slope, intercept = np.polyfit(t, y, 1)         # linear trend
        trend = intercept + slope * t
        resid = y - trend
        how = t % WEEK                                  # hour-of-week bucket
        profile = np.array([resid[how == h].mean() if np.any(how == h) else 0.0 for h in range(WEEK)])
        sigma = float((resid - profile[how]).std(ddof=1)) or 1e-6

        ft = np.arange(n, n + horizon_hours)
        fhow = ft % WEEK
        point = intercept + slope * ft + profile[fhow]
        point = np.clip(point, 1e-4, None)
        lower = np.clip(point - Z90 * sigma, 0.0, None)
        upper = point + Z90 * sigma
        return Forecast(
            horizon_hours,
            pd.Series(point, index=future_index),
            pd.Series(lower, index=future_index),
            pd.Series(upper, index=future_index),
            self.MODEL_ID, confident=True,
        )


class StatsForecaster:
    """Production default: statsforecast AutoETS with weekly seasonality. Used if importable."""
    MODEL_ID = "statsforecast:AutoETS"

    def forecast(self, history: pd.Series, horizon_hours: int) -> Forecast:
        from statsforecast import StatsForecast
        from statsforecast.models import AutoETS
        h = history.dropna()
        future_index = pd.RangeIndex(len(h), len(h) + horizon_hours)
        if len(h) < MIN_POINTS:
            flat = pd.Series(np.repeat(h.to_numpy()[-1] if len(h) else 0.0, horizon_hours), index=future_index)
            return Forecast(horizon_hours, flat, flat, flat, self.MODEL_ID, confident=False)
        df = h.reset_index(drop=True).reset_index()
        df.columns = ["ds", "y"]; df["unique_id"] = "pod"
        sf = StatsForecast(models=[AutoETS(season_length=WEEK)], freq=1)
        sf.fit(df)
        fc = sf.predict(h=horizon_hours, level=[90])
        return Forecast(
            horizon_hours,
            pd.Series(fc["AutoETS"].to_numpy(), index=future_index),
            pd.Series(fc["AutoETS-lo-90"].to_numpy(), index=future_index),
            pd.Series(fc["AutoETS-hi-90"].to_numpy(), index=future_index),
            self.MODEL_ID, confident=True,
        )


def default_forecaster() -> Forecaster:
    """Use statsforecast if installed; otherwise the dependency-free fallback."""
    try:
        import statsforecast  # noqa: F401
        return StatsForecaster()
    except Exception:
        return SeasonalNaiveForecaster()
